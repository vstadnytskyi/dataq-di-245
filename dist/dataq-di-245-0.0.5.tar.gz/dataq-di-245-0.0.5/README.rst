============
dataq DI-245
============

.. image:: https://img.shields.io/travis/vstadnytskyi/dataq-di-245.svg
        :target: https://travis-ci.org/vstadnytskyi/dataq-di-245

.. image:: https://img.shields.io/pypi/v/dataq-di-245.svg
        :target: https://pypi.python.org/pypi/dataq-di-245


Dataq DI-245 Data Acquisition unit

* Free software: 3-clause BSD license
* Documentation: (COMING SOON!) https://vstadnytskyi.github.io/dataq-di-245.

Features
--------

* TODO

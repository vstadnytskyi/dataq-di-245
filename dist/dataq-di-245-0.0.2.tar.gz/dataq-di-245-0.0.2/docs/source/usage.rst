=====
Usage
=====

Start by importing dataq DI-245.

.. code-block:: python

    import dataq_di_245

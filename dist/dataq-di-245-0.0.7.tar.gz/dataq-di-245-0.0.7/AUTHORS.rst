=======
Credits
=======

Maintainer
----------

* Valentyn Stadnytskyi <v.stadnytskyi@gmail.com>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst

============
Installation
============

At the command line::

    $ pip install dataq-di-245
